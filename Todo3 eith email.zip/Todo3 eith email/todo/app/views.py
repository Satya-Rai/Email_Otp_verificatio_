from django.shortcuts import render , redirect,HttpResponse,HttpResponseRedirect
from django.http import HttpResponse
from django.contrib.auth import authenticate , login as loginUser  , logout, update_session_auth_hash
from django.contrib.auth.forms import AuthenticationForm , PasswordChangeForm
# Create your views here.
from app.forms import TODOForm,signupForm,forget_pass_form
#from django.views.generic import TemplateView, FormView, CreateView
#from django.urls import reverse_lazy, reverse 
from app.models import TODO,MyCustomModel,user_otp
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
import random
from django.core.mail import send_mail
from django.conf import settings
from django.contrib import messages
#from django.template.loader import render_to_string
#from .tokens import account_activation_token
#from django.core.mail import send_mail
# from .utils import *
# import uuid
from django.contrib.auth import get_user_model
from functools import lru_cache
from django.views.decorators.cache import cache_page


#[(u.email, u.is_active, u.has_usable_password()) for u in get_user_model().objects.all()]


from todo import settings
User = get_user_model()

#@cache_page(60)
@login_required(login_url='login')
def home(request):
    if request.user.is_authenticated:
        user = request.user
        form = TODOForm()
        todos = TODO.objects.filter(user = user).order_by('priority')
        #print(todos.__dict__)
        if (request.session.has_key('uid')):
            res = request.session['uid']
            print(res)
            return render(request , 'index.html' , context={'form' : form , 'todos' : todos, })
        else:
            return redirect('login')

def login(request):
    
    if request.method == 'GET':
        form1 = AuthenticationForm()
        context = {
            "form" : form1
        }
        return render(request , 'login.html' , context=context )
    else:
        form = AuthenticationForm(data=request.POST)
        print(form.is_valid())
        
        #s = MyCustomModel.objects.filter(email_id =request.POST['email'], password = request.POST['password'])
        
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            data=request.POST.get('username')
            #print(data)
            user = authenticate(username = username , password = password)
        

            if user is not None:
                loginUser(request , user)
                request.session['uid'] = request.POST.get('username') 
                return redirect('home')
        else:
            context = {
                "form" : form
            }
            return render(request , 'login.html' , context=context )


#@lru_cache(maxsize = 32)
def signup(request):

    if request.method == 'GET':
        form = signupForm()
        context = {
            "form" : form
        }
        return render(request , 'signup.html' , context=context)
    else:
        #print(request.POST)
        form = signupForm(request.POST)  
        context = {
            "form" : form
        }
        if form.is_valid():
            user = form.save()
            print(user)
            if user is not None:
                return redirect('otp_send')
        else:
            return render(request , 'signup.html' , context=context)

def otp_send(request):
  

    usr = MyCustomModel.objects.get(email = request.POST.get('email'))
    #usr = request.POST.get('username')
    print(usr)
    usr.active = False
    usr.save()
    usr_otp = random.randint(100000,999999)
    print(user_otp)

   
    user_otp.objects.create(user = usr, otp = usr_otp)
    msg = f'Hii Your otp is {usr_otp}'

    send_mail(
        "Welcome to our ToDo App. plz verify your mail",
				 msg,
				 settings.EMAIL_HOST_USER,
				 [usr.email,],
				 fail_silently = False,
    )
    return render(request, 'otp_check.html', {'otp':True, 'usr':usr})

def verify(request):
    if request.method == 'POST':
        get_otp = request.POST.get('otp')
        if get_otp:
            usr = MyCustomModel.objects.get(email=request.POST.get('email'))
        
            if int(get_otp) == user_otp.objects.filter(user=usr).last().otp:
                usr.is_active = True
                usr.save()
                messages.success(request, f'Account is Created For {usr.username}')
                return redirect('login')
            else:
                messages.warning(request, f'You Entered a Wrong OTP')
                return render(request, 'otp_check.html', {'otp': True, 'usr': usr})










# def resend_otp(request):
# 	if request.method == "GET":
# 		get_usr = request.GET['usr']
# 		if MyCustomModel.objects.filter(username = get_usr).exists() and not MyCustomModel.objects.get(username = get_usr).is_active:
# 			usr = MyCustomModel.objects.get(username=get_usr)
# 			usr_otp = random.randint(100000, 999999)
# 			user_otp.objects.create(user = usr, otp = usr_otp)
# 			mess = f"Hello {usr.username},\nYour OTP is {usr_otp}\nThanks!"

# 			print(send_mail(
# 				"Welcome to our ToDo App. plz verify your mail",
# 				mess,
# 				settings.EMAIL_HOST_USER,
# 				[usr.email],
# 				fail_silently = False
# 				))
# 			return HttpResponse("Resend")

# 	return HttpResponse("Can't Send ")



@login_required(login_url='login')
def add_todo(request):
    if request.user.is_authenticated:
        user = request.user
        #print(user)
        form = TODOForm(request.POST,request.FILES)
        #print(request.POST, request.FILES) 
        if form.is_valid():
            print(form.cleaned_data)
            todo = form.save(commit=False)
            todo.user = user
            todo.save()
            #print(todo)
            return redirect("home")
        else: 
            return render(request , 'index.html' , context={'form' : form})


def delete_todo(request , id ):
    print(id)
    TODO.objects.get(pk = id).delete()
    return redirect('home')

def change_todo(request , id  , status):
    todo = TODO.objects.get(pk = id)
    todo.status = status
    todo.save()
    return redirect('home')


@login_required(login_url='login')
def change_password(request ):
    if request.user.is_authenticated:
        if request.method == 'POST':
            fm = PasswordChangeForm(user=request.user, data = request.POST)
            if fm.is_valid():
                fm.save()
                #update_session_auth_hash(request, fm.user)
            return redirect('home')
        else:
            fm = PasswordChangeForm(user = request.user)
        #user = request.user
        return render(request, 'changepass.html', {'form': fm})

# def forget_password(request):
#     if request.user.is_authenticated:
#         if request.method == 'POST':
#             fm = forget_pass_form(user=request.user, data = request.POST)
#             if fm.is_valid():
#                 fm.save()
#                 #update_session_auth_hash(request, fm.user)
#             return redirect('login')
#         else:
#             fm = forget_pass_form(user = request.user)
#         #user = request.user
#         return render(request, 'forgetpass.html', {'form': fm})

def signout(request):
    request.session.clear()
    logout(request)
    return redirect('login')
